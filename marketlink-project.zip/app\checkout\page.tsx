"use client";

import { useState } from "react";
import PaystackPop from "@paystack/inline-js";

export default function CheckoutPage() {
  const [isPaying, setIsPaying] = useState(false);
  const [paymentOpen, setPaymentOpen] = useState(false);

  // Match your actual cart
  const subtotal = 72000;
  const deliveryFee = 3000;
  const total = subtotal + deliveryFee;

  const handlePayment = async () => {
    const emailInput = document.getElementById(
      "customer-email"
    ) as HTMLInputElement | null;

    const email = emailInput?.value.trim();

    if (!email) {
      alert("Please enter your email address.");
      emailInput?.focus();
      return;
    }

    try {
      setIsPaying(true);

      const response = await fetch("/api/payment/initialize", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email,
          amount: total,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message || "Unable to initialize payment."
        );
      }

      if (!data.accessCode) {
        throw new Error(
          "Paystack did not return a payment access code."
        );
      }

      const popup = new PaystackPop();

      popup.resumeTransaction(data.accessCode);
    } catch (error) {
      console.error("Payment error:", error);

      alert(
        error instanceof Error
          ? error.message
          : "Unable to start payment."
      );

      setIsPaying(false);
    }
  };

  return (
    <main className="min-h-screen bg-gray-50">

      {/* HEADER */}
      <header className="border-b bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-5">
          <div>
            <h1 className="text-2xl font-bold text-green-700">
              MarketLink
            </h1>

            <p className="text-sm text-gray-500">
              Secure Checkout
            </p>
          </div>

          <div className="text-sm text-gray-500">
            🔒 Secure
          </div>
        </div>
      </header>

      {/* MAIN */}
      <div className="mx-auto max-w-6xl px-4 py-8">

        <div className="mb-6">
          <a
            href="/cart"
            className="font-semibold text-green-700"
          >
            ← Back to Cart
          </a>

          <h1 className="mt-5 text-3xl font-bold">
            Checkout
          </h1>

          <p className="mt-2 text-gray-500">
            Complete your delivery and payment.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">

          {/* LEFT SIDE */}
          <div className="space-y-6 lg:col-span-2">

            {/* DELIVERY INFORMATION */}
            <section className="rounded-2xl bg-white p-6 shadow-sm">

              <h2 className="text-2xl font-bold">
                1. Delivery Information
              </h2>

              <p className="mt-1 mb-6 text-gray-500">
                Where should we deliver your order?
              </p>

              <div className="grid gap-5 md:grid-cols-2">

                <div>
                  <label className="mb-2 block font-semibold">
                    Full Name
                  </label>

                  <input
                    type="text"
                    placeholder="Enter your full name"
                    className="w-full rounded-xl border border-gray-300 px-4 py-4 outline-none focus:border-green-600"
                  />
                </div>

                <div>
                  <label className="mb-2 block font-semibold">
                    Phone Number
                  </label>

                  <input
                    type="tel"
                    placeholder="e.g. 08012345678"
                    className="w-full rounded-xl border border-gray-300 px-4 py-4 outline-none focus:border-green-600"
                  />
                </div>

                <div>
                  <label className="mb-2 block font-semibold">
                    Email Address
                  </label>

                  <input
                    id="customer-email"
                    type="email"
                    placeholder="you@example.com"
                    className="w-full rounded-xl border border-gray-300 px-4 py-4 outline-none focus:border-green-600"
                  />
                </div>

                <div>
                  <label className="mb-2 block font-semibold">
                    State
                  </label>

                  <select className="w-full rounded-xl border border-gray-300 px-4 py-4 outline-none focus:border-green-600">
                    <option value="">
                      Select your state
                    </option>

                    <option>Lagos</option>
                    <option>Abuja</option>
                    <option>Kano</option>
                    <option>Rivers</option>
                    <option>Oyo</option>
                    <option>Enugu</option>
                    <option>Kaduna</option>
                  </select>
                </div>

                <div>
                  <label className="mb-2 block font-semibold">
                    LGA
                  </label>

                  <input
                    type="text"
                    placeholder="Enter your LGA"
                    className="w-full rounded-xl border border-gray-300 px-4 py-4 outline-none focus:border-green-600"
                  />
                </div>

                <div>
                  <label className="mb-2 block font-semibold">
                    Delivery Address
                  </label>

                  <input
                    type="text"
                    placeholder="House number, street, area..."
                    className="w-full rounded-xl border border-gray-300 px-4 py-4 outline-none focus:border-green-600"
                  />
                </div>

              </div>

              <div className="mt-5">
                <label className="mb-2 block font-semibold">
                  Delivery Instructions
                  <span className="ml-2 font-normal text-gray-400">
                    Optional
                  </span>
                </label>

                <textarea
                  rows={3}
                  placeholder="Example: Call me when you arrive."
                  className="w-full rounded-xl border border-gray-300 px-4 py-4 outline-none focus:border-green-600"
                />
              </div>

              <button
                type="button"
                className="mt-5 rounded-xl border border-green-600 bg-green-50 px-5 py-3 font-semibold text-green-700"
              >
                📍 Use My Current Location
              </button>

            </section>

            {/* DELIVERY METHOD */}
            <section className="rounded-2xl bg-white p-6 shadow-sm">

              <h2 className="text-2xl font-bold">
                2. Delivery Method
              </h2>

              <div className="mt-5 space-y-3">

                <div className="flex items-center justify-between rounded-xl border-2 border-green-600 bg-green-50 p-5">

                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="delivery"
                      defaultChecked
                    />

                    <div>
                      <p className="font-bold">
                        Standard Delivery
                      </p>

                      <p className="text-sm text-gray-500">
                        Delivery within 1–2 days
                      </p>
                    </div>
                  </div>

                  <p className="font-bold">
                    ₦3,000
                  </p>

                </div>

                <div className="flex items-center justify-between rounded-xl border border-gray-300 p-5">

                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="delivery"
                    />

                    <div>
                      <p className="font-bold">
                        Express Delivery
                      </p>

                      <p className="text-sm text-gray-500">
                        Faster delivery
                      </p>
                    </div>
                  </div>

                  <p className="font-bold">
                    ₦5,000
                  </p>

                </div>

              </div>
            </section>

            {/* PAYMENT */}
            <section className="rounded-2xl bg-white p-6 shadow-sm">

              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold">
                    3. Payment
                  </h2>

                  <p className="mt-1 text-gray-500">
                    Choose your payment method.
                  </p>
                </div>

                <span className="rounded-full bg-green-100 px-3 py-1 text-xs font-bold text-green-700">
                  SECURE
                </span>
              </div>

              {/* PAYMENT METHOD DISPLAY */}
              <div className="mt-6 space-y-3">

                <div
                  className={`cursor-pointer rounded-2xl border-2 p-5 transition ${
                    paymentOpen
                      ? "border-green-600 bg-green-50"
                      : "border-gray-200 bg-white"
                  }`}
                  onClick={() => setPaymentOpen(true)}
                >

                  <div className="flex items-center gap-4">

                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-green-600 text-xl text-white">
                      💳
                    </div>

                    <div className="flex-1">

                      <p className="font-bold">
                        Pay with Paystack
                      </p>

                      <p className="text-sm text-gray-500">
                        Card, Bank Transfer, USSD and more
                      </p>

                    </div>

                    <div className="text-green-600">
                      ✓
                    </div>

                  </div>

                </div>

              </div>

              {/* PAYMENT DETAILS PREVIEW */}
              {paymentOpen && (
                <div className="mt-5 rounded-2xl border bg-gray-50 p-5">

                  <p className="font-bold">
                    Payment Method
                  </p>

                  <p className="mt-1 text-sm text-gray-500">
                    When you continue, Paystack will open securely
                    and allow you to select your payment method.
                  </p>

                  <div className="mt-4 grid grid-cols-3 gap-3">

                    <div className="rounded-xl bg-white p-4 text-center">
                      <div className="text-xl">
                        💳
                      </div>

                      <p className="mt-1 text-xs font-semibold">
                        Card
                      </p>
                    </div>

                    <div className="rounded-xl bg-white p-4 text-center">
                      <div className="text-xl">
                        🏦
                      </div>

                      <p className="mt-1 text-xs font-semibold">
                        Bank
                      </p>
                    </div>

                    <div className="rounded-xl bg-white p-4 text-center">
                      <div className="text-xl">
                        📱
                      </div>

                      <p className="mt-1 text-xs font-semibold">
                        USSD
                      </p>
                    </div>

                  </div>

                  <div className="mt-5 flex items-center justify-between rounded-xl bg-white p-4">

                    <span className="font-semibold">
                      Amount
                    </span>

                    <span className="text-xl font-bold text-green-700">
                      ₦{total.toLocaleString()}
                    </span>

                  </div>

                  <button
                    type="button"
                    onClick={handlePayment}
                    disabled={isPaying}
                    className="mt-5 w-full rounded-xl bg-green-600 px-5 py-4 text-lg font-bold text-white transition hover:bg-green-700 disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {isPaying
                      ? "Opening Payment..."
                      : `Pay ₦${total.toLocaleString()}`}
                  </button>

                  <p className="mt-3 text-center text-xs text-gray-500">
                    🔒 Secure payment powered by Paystack
                  </p>

                </div>
              )}

            </section>
          </div>

          {/* ORDER SUMMARY */}
          <aside className="h-fit rounded-2xl bg-white p-6 shadow-sm lg:sticky lg:top-6">

            <h2 className="text-xl font-bold">
              Order Summary
            </h2>

            {/* PRODUCT */}
            <div className="mt-6 border-b pb-5">

              <div className="flex justify-between gap-4">

                <div>
                  <h3 className="font-bold">
                    Rice 50kg Bag
                  </h3>

                  <p className="mt-1 text-sm text-gray-500">
                    Quantity: 1
                  </p>

                  <p className="mt-2 text-sm text-gray-500">
                    📍 Mile 12 Market
                  </p>

                  <p className="text-sm text-gray-500">
                    Seller: John Market Store
                  </p>
                </div>

                <p className="font-bold">
                  ₦72,000
                </p>

              </div>

            </div>

            {/* TOTAL */}
            <div className="space-y-4 border-b py-5">

              <div className="flex justify-between">
                <span className="text-gray-600">
                  Subtotal
                </span>

                <span className="font-medium">
                  ₦72,000
                </span>
              </div>

              <div className="flex justify-between">
                <span className="text-gray-600">
                  Delivery
                </span>

                <span className="font-medium">
                  ₦3,000
                </span>
              </div>

            </div>

            <div className="flex justify-between py-5 text-xl font-bold">

              <span>
                Total
              </span>

              <span className="text-green-700">
                ₦{total.toLocaleString()}
              </span>

            </div>

            <button
              type="button"
              onClick={() => setPaymentOpen(true)}
              className="w-full rounded-xl bg-green-600 px-5 py-4 font-bold text-white hover:bg-green-700"
            >
              Continue to Payment
            </button>

            <p className="mt-4 text-center text-xs text-gray-500">
              🔒 Secure checkout
            </p>

          </aside>

        </div>
      </div>
    </main>
  );
}